
import { NextFunction, Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { ZodError } from "zod";
import handelZodError from "../error/handelZorError";
import AppError from "../error/AppError";


const globalErrorHandler = (
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  let statusCode = StatusCodes.INTERNAL_SERVER_ERROR;
  let success = false;
  let message = err.message || "Something went wrong!";
  let error = err;

  if (err instanceof ZodError) {
    const simplifedError = handelZodError(err);
    statusCode = simplifedError?.statusCode;
    message = simplifedError?.message;
    error = simplifedError.errorSources;
  } else if (err.code === "P2025") {
    message = "Validation Error";
    error = err.message;
  } else if (err.code === "P2002") {
    message = "Duplicate error";
    error = err.meta;
  } else if (err instanceof AppError) {
    statusCode = err?.statusCode;
    message = err?.message;
    error = [
      {
        path: "",
        message: err.message,
      },
    ];
  } else if (err instanceof Error) {
    message = err?.message;
    error = [
      {
        path: "",
        message: err.message,
      },
    ];
  }

  res.status(statusCode).json({
    success: false,
    message,
    error,
  });
};

export default globalErrorHandler;
